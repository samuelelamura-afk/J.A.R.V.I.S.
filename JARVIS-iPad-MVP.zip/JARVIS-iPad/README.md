# JARVIS iPad — MVP PWA

Prototipo web progressive app con interfaccia responsive per iPad/iPhone.

## Funzionalità attuali
- Dashboard minimal
- Navigazione Dashboard / AI Assistant / Scuola / Planner
- Planner locale: aggiungi, completa ed elimina attività; persistenza in localStorage
- Selettore UI del modello (ChatGPT, Gemini, Claude, AllPlus placeholder)
- UI chat dimostrativa: **non invoca ancora un modello AI**
- Manifest PWA e service worker per caching shell

## Avvio locale
Serve un server HTTP statico. Da un computer con Python:

```bash
python3 -m http.server 8000
```

Aprire `http://IP_DEL_COMPUTER:8000` da Safari su iPad, sulla stessa rete Wi-Fi.
Per PWA/service worker, un deployment HTTPS è preferibile e normalmente necessario fuori da localhost.

## Aggiungere alla schermata Home
Da Safari su iPad: Condividi → Aggiungi alla schermata Home.

## Prossimi passaggi
1. Deploy HTTPS (es. hosting statico).
2. Creare backend con autenticazione e API AI.
3. Conservare le chiavi API esclusivamente lato server, mai nel frontend.
4. Collegare i modelli effettivamente disponibili e definire provider e costi.
5. Implementare upload e gestione file con permessi espliciti.

Questo è un prototipo frontend, non un'installazione del repository OpenJarvis originale.
