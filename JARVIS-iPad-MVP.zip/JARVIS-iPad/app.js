const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];
const STORAGE_KEY = 'jarvis-ipad-tasks-v1';
let tasks = loadTasks();

function loadTasks(){ try { return JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]'); } catch { return []; } }
function saveTasks(){ localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks)); renderTasks(); }
function navigate(page){
  $$('.page').forEach(el => el.classList.toggle('active', el.id === `page-${page}`));
  $$('.nav-item').forEach(el => el.classList.toggle('active', el.dataset.page === page));
  window.scrollTo({top:0,behavior:'smooth'});
}
$$('.nav-item').forEach(button => button.addEventListener('click', () => navigate(button.dataset.page)));
$$('[data-goto]').forEach(button => button.addEventListener('click', () => navigate(button.dataset.goto)));

function renderTasks(){
  const sorted = [...tasks].sort((a,b) => (a.date || '9999').localeCompare(b.date || '9999'));
  const markup = sorted.length ? sorted.map(task => `<div class="task-row"><input class="task-check" type="checkbox" data-toggle="${task.id}" ${task.done?'checked':''} aria-label="Completa attività"><div class="task-details"><div class="task-name ${task.done?'done':''}">${escapeHtml(task.title)}</div><div class="task-meta">${escapeHtml(task.subject || 'Generale')}${task.date ? ' · Scadenza ' + formatDate(task.date) : ''}</div></div><button class="delete-task" data-delete="${task.id}" aria-label="Elimina attività">×</button></div>`).join('') : '<p class="empty-state">Non ci sono ancora attività. Aggiungine dal Planner.</p>';
  $('#home-task-list').innerHTML = markup;
  $('#planner-task-list').innerHTML = markup;
  $('#task-count').textContent = tasks.filter(t=>!t.done).length;
  $$('[data-toggle]').forEach(input => input.addEventListener('change', () => { const item=tasks.find(t=>t.id===input.dataset.toggle); if(item){item.done=input.checked;saveTasks();} }));
  $$('[data-delete]').forEach(button => button.addEventListener('click', () => { tasks=tasks.filter(t=>t.id!==button.dataset.delete);saveTasks(); }));
}
function formatDate(value){const [y,m,d]=value.split('-');return `${d}/${m}/${y}`;}
function escapeHtml(value){return String(value).replace(/[&<>"']/g, ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));}
const dialog=$('#task-dialog');
$('#add-task-button').addEventListener('click',()=>dialog.showModal());
$('#close-dialog').addEventListener('click',()=>dialog.close());
$('#cancel-task').addEventListener('click',()=>dialog.close());
$('#task-form').addEventListener('submit',(event)=>{
  event.preventDefault(); const title=$('#task-title').value.trim(); if(!title)return;
  tasks.push({id:crypto.randomUUID(),title,date:$('#task-date').value,subject:$('#task-subject').value.trim(),done:false});
  saveTasks();event.target.reset();dialog.close();
});

$('#chat-form').addEventListener('submit',(event)=>{
  event.preventDefault();const input=$('#chat-input');const message=input.value.trim();if(!message)return;
  const area=$('#chat-messages');const user=document.createElement('div');user.className='user-message';const p=document.createElement('p');p.textContent=message;user.appendChild(p);area.appendChild(user);
  const note=document.createElement('div');note.className='assistant-message';note.innerHTML='<div class="message-mark">J</div><div><strong>JARVIS</strong><p>Il prototipo UI è pronto, ma il provider AI non è ancora collegato. Nel prossimo passaggio si può configurare un backend sicuro per inviare questa richiesta al modello selezionato.</p></div>';area.appendChild(note);input.value='';area.scrollTop=area.scrollHeight;
});
if('serviceWorker' in navigator && location.protocol.startsWith('http')) navigator.serviceWorker.register('./sw.js').catch(()=>{});
renderTasks();
